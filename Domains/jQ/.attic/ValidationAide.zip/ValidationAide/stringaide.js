//----------------------------------------------------------------------------------
// File: stringaide.js 
//
// Copyright (c) 2007 Ste Brennan (dnaide.com)
// Licensed under the COMMON DEVELOPMENT AND DISTRIBUTION LICENSE (CDDL) Version 1.0
// http://www.opensource.org/licenses/cddl1.php
//
//----------------------------------------------------------------------------------
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('d.W(h.V,{U:6(f){7 3.e(0,f)},T:6(f){7 3.e((3.9-f),3.9)},S:6(c,a){4(!c){c=0};4(!a||a>3.9){a=3.9};4(a!=3.9){a=c+a};7 3.e(c,a)},R:6(n,y){5 2=3;m(2.Q(n)>-1){2=2.k(n,y)}7 2},P:6(){5 2=3;2=3.x();7 2.w()},x:6(){5 2=3;m(2.l(0)==" "){2=2.k(2.l(0),"")}7 2},w:6(){5 2=3;m(2.l((2.9-1))==" "){2=2.e(0,2.9-1)}7 2},O:6(){5 v=j N(\'\\\\s{1,}\',\'M\');7 3.k(v,\'\')}});d.L.K=6(J){5 2=j h();4(3.9>0){5 8=3[0];5 b=j h(8.b);5 t=8.I;4(t=="H"||t=="G"){4(b==""){4(8.u)2=8.r}g{d("F[@b="+b+"]").E(6(){4(3.u){4(2!="")2+=",";2+=3.r}})}}g 4(t=="q-D"||t=="q-C"){B(5 i=0;i<8.9;i++){4(8.p[i].A){4(2!="")2+=",";2+=8.p[i].o}}}g{2=8.o}}7 d.z(2)};',59,59,'||retval|this|if|var|function|return|elm|length|end|name|start|jQuery|substring|characterCount|else|String||new|replace|charAt|while|replaceThis|value|options|select|id|||checked|exp|TrimEnd|TrimStart|replaceWith|trim|selected|for|multiple|one|each|input|radio|checkbox|type|successful|fieldStringVal|fn|gi|RegExp|RemoveAllWhitespace|Trim|indexOf|Replace|Mid|Right|Left|prototype|extend'.split('|'),0,{}))
